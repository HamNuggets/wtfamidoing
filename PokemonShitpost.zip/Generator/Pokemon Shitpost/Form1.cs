﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pokemon_Wikipedia
{
    public partial class Form1 : Form
    {
        byte[] gamedata;
        PokemonHexToChar phtc = new PokemonHexToChar();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Button2_Click(null, null);
        }
        public string BanChars(string s,string[] ban)
        {
            foreach(var b in ban)
                s = s.Replace(b, " ");

            while (!s.Contains("  "))
                s.Replace("  ", " ");

            return s;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if(lbcheckrom.Visible || lbchecksource.Visible)
            {
                MessageBox.Show("One of the requirementss were not met. click on refresh to check requirements again");
                return;
            }


            gamedata = File.ReadAllBytes("emerald.gba");



            StringBuilder sb = new StringBuilder();

            phtc.InitSingleCharBreakLines();
            foreach (byte b in gamedata)
            {
                if (phtc.dico.TryGetValue(b, out string c))
                    sb.Append(c);
                else
                    sb.Append("#");

            }

            string s = sb.ToString();

            string[] allLines = s.Split('\n');

            List<pkmnLine> allPkmnLines = new List<pkmnLine>();

            for (int i = 0; i < allLines.Length; i++)
            {
                var pline = new pkmnLine();
                pline.line = allLines[i];

                if (allPkmnLines.Count == 0)
                    pline.startIndex = 0;
                else
                {
                    var lastPline = allPkmnLines[allPkmnLines.Count - 1];
                    pline.startIndex = lastPline.startIndex + lastPline.length + 1;
                }

                allPkmnLines.Add(pline);

            }

            for (int i = 0; i < 19977 - 1; i++) { allLines[i] = "$"; }
            for (int i = 20115 - 1; i < 20136 - 1; i++) { allLines[i] = "$"; }
            for (int i = 20375 - 1; i < 20383 - 1; i++) { allLines[i] = "$"; }
            for (int i = 20393 - 1; i < 20410 - 1; i++) { allLines[i] = "$"; }
            for (int i = 20436 - 1; i < 20441 - 1; i++) { allLines[i] = "$"; }
            for (int i = 28947 - 1; i < 31451 - 1; i++) { allLines[i] = "$"; }
            for (int i = 31643 - 1; i < 34312 - 1; i++) { allLines[i] = "$"; }
            for (int i = 36183 - 1; i < 37683 - 1; i++) { allLines[i] = "$"; }
            for (int i = 37711 - 1; i < 56362 - 1; i++) { allLines[i] = "$"; }
            for (int i = 57194 - 1; i < 58611 - 1; i++) { allLines[i] = "$"; }
            for (int i = 59308 - 1; i < 59319 - 1; i++) { allLines[i] = "$"; }
            for (int i = 60001 - 1; i < 60927 - 1; i++) { allLines[i] = "$"; }
            for (int i = 61937 - 1; i < 62403 - 1; i++) { allLines[i] = "$"; }
            for (int i = 62599 - 1; i < 62637 - 1; i++) { allLines[i] = "$"; }
            for (int i = 62877 - 1; i < 63978 - 1; i++) { allLines[i] = "$"; }
            for (int i = 64019 - 1; i < 66032 - 1; i++) { allLines[i] = "$"; }
            for (int i = 66575 - 1; i < 67408 - 1; i++) { allLines[i] = "$"; }
            for (int i = 68285 - 1; i < 68349 - 1; i++) { allLines[i] = "$"; }
            for (int i = 68433 - 1; i < 68493 - 1; i++) { allLines[i] = "$"; }
            for (int i = 68583 - 1; i < 68643 - 1; i++) { allLines[i] = "$"; }
            for (int i = 68699 - 1; i < 69438 - 1; i++) { allLines[i] = "$"; }
            for (int i = 69596 - 1; i < 69663 - 1; i++) { allLines[i] = "$"; }
            for (int i = 71424 - 1; i < 78034 - 1; i++) { allLines[i] = "$"; }
            for (int i = 78137 - 1; i < 79126 - 1; i++) { allLines[i] = "$"; }
            for (int i = 79520 - 1; i < 80073 - 1; i++) { allLines[i] = "$"; }
            for (int i = 80384 - 1; i < 80452 - 1; i++) { allLines[i] = "$"; }
            for (int i = 80517 - 1; i < 81561 - 1; i++) { allLines[i] = "$"; }
            for (int i = 82343 - 1; i < allLines.Length; i++) { allLines[i] = "$"; }

            //postfix blacklists
            for (int i = 20515 - 1; i < 20531 - 1; i++) { allLines[i] = "$"; }
            for (int i = 20568 - 1; i < 20577 - 1; i++) { allLines[i] = "$"; }
            for (int i = 82262 - 1; i < 82263 - 1; i++) { allLines[i] = "$"; }




            #region sanitizing

            for (int i = 0; i < allLines.Length; i++)
            {
                if (allLines[i].Trim() == "")
                {
                    allLines[i] = "$";
                    continue;
                }

                if (allLines[i].Trim().Length < 6)
                {
                    allLines[i] = "$";
                    continue;
                }

                int nbSharps = 0;
                //char[] illegalchars = { ' ', '&', 'é' };
                //foreach(var illegalchar in illegalchars)

                for (int loop = 0; loop < 2; loop++)
                {
                    string line = allLines[i];
                    StringBuilder newLine = new StringBuilder(line);

                    nbSharps = 0;
                    int nbCharsSinceSharp = -1;

                    bool PrevSpace = false;

                    if (line[0] == ' ')
                        newLine[0] = '#';

                    if (line[line.Length - 1] == ' ')
                        newLine[line.Length - 1] = '#';

                    if (line.Length > 1 && line[line.Length - 1] != '#' && line[line.Length - 2] == '#')
                        newLine[line.Length - 1] = '#';

                    for (int j = 0; j < line.Length; j++)
                    {
                        if (j + 1 != line.Length && line[j] == '#' && line[j + 1] == ' ')
                        { newLine[j + 1] = '#'; }

                        if (j > 0 && line[j] == '#' && line[j - 1] == ' ')
                        { newLine[j - 1] = '#'; }


                        if (line[j] == '#')
                        {
                            nbSharps++;

                            if (nbCharsSinceSharp > 0 && nbCharsSinceSharp < 5)
                            {
                                for (int k = nbCharsSinceSharp; k > 0; k--)
                                    newLine[j - k] = '#';
                            }

                            nbCharsSinceSharp = 0;
                        }
                        else if (nbCharsSinceSharp != -1)
                            nbCharsSinceSharp++;

                        if (line[j] == ' ')
                        {
                            if (PrevSpace)
                            {
                                newLine[j - 1] = '#';
                                newLine[j] = '#';
                            }

                            PrevSpace = true;
                        }
                        else
                            PrevSpace = false;




                    }
                    if (newLine != null)
                        allLines[i] = newLine.ToString();
                }



            }

            for (int i = 0; i < allPkmnLines.Count; i++)
                allPkmnLines[i].cleanLine = allLines[i];

            foreach (var item in allPkmnLines)
            {
                if (item.cleanLine[0] == '$')
                {
                    continue;
                }

                for (int i = 0; i < item.length; i++)
                    if (item.cleanLine[i] != '#')
                    {
                        item.legal = true;
                        break;
                    }
            }

            #endregion

            #region textreplacement


            int number = 0;
            string source = File.ReadAllText("source.txt");

            List<string> allsourcewords = BanChars(source, new string[] {
                ".",
                ",",
                "?",
                "!",
            }).Split(' ').Where(it => !string.IsNullOrWhiteSpace(it)).ToList();

            if (File.Exists("23letterwords.txt"))
            {
                allsourcewords = allsourcewords.Where(it => it.Length != 2 && it.Length != 2).ToList();
                allsourcewords.AddRange(File.ReadAllLines("23letterwords.txt", Encoding.UTF8).Select(it => it.Trim()));

            }
            string[] sourcewords = allsourcewords.ToArray();

            foreach (var item in allPkmnLines.Where(it => it.legal))
            {
                while (source[number] != ' ')
                {
                    number++;
                    if (number == source.Length)
                        number = 0;
                }

                number++;
                if (number == source.Length)
                    number = 0;

                bool firstChar = true;

                for (int i = 0; i < item.length; i++)
                    if (item.cleanLine[i] != '#')
                    {

                        if (firstChar)
                        {
                            int replaceLength = 0;

                            do
                            {
                                replaceLength++;
                            } while (item.cleanLine.Length != (i + replaceLength) && item.cleanLine[i + replaceLength] != '#');


                            if (replaceLength < 12)
                            {
                                Random rand = new Random(Guid.NewGuid().GetHashCode());
                                var rightSizedWords = sourcewords.Where(it => it.Length == replaceLength);
                                string ChosenWord = rightSizedWords.ElementAt(rand.Next(rightSizedWords.Count()));

                                for (int letternb = 0; letternb < ChosenWord.Length; letternb++)
                                {
                                    if (phtc.reverseDico.TryGetValue(ChosenWord[letternb].ToString(), out byte b2))
                                        gamedata[item.startIndex + i] = b2;
                                    else
                                        gamedata[item.startIndex + i] = 0x00;
                                    i++;
                                }

                                continue;
                            }
                        }
                        firstChar = false;

                        if (phtc.reverseDico.TryGetValue(source[number].ToString(), out byte b))
                            gamedata[item.startIndex + i] = b;
                        else
                            gamedata[item.startIndex + i] = 0x00;

                        number++;
                        if (number == source.Length)
                            number = 0;
                    }
                    else
                    {
                        while (source[number] != ' ')
                        {
                            number++;
                            if (number == source.Length)
                                number = 0;
                        }
                        number++;
                        if (number == source.Length)
                            number = 0;
                    }
            }

            #endregion

            #region rombake
            //allLines = allLines.Where(it => it.Trim() != "$").ToArray();

            string rejoinded = string.Join("\n", allLines);

            File.WriteAllText("AllLines.txt", rejoinded);
            File.WriteAllBytes("newGameData.gba", gamedata);

            #endregion

            MessageBox.Show("Generated successlly. engoy");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            if (File.Exists("emerald.gba"))
            {
                lbcheckrom.Text = "✓";
                lbcheckrom.ForeColor = Color.DarkGreen;
            }

            if (File.Exists("source.txt"))
            {
                lbchecksource.Text = "✓";
                lbchecksource.ForeColor = Color.DarkGreen;
            }

            if (File.Exists("23letterwords.txt"))
                lb23letterweods.Visible = true;
        }
    }
}
