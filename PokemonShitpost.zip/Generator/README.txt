open the solution in vs2019
read the code
compile in debug mode
put emerald.gba in the debug folder
edit the text files in the debug folder
pray that the thing works

no fixes no revisions no problems
enjoy

-phil